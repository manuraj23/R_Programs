(	Z <- 50:60)
(z<-seq(60))
(	Z <- c(50,51,52,53,54,55,56,57,58,59,60))
(m <- matrix(nrow = 1, ncol = 2))
(mat <- matrix(5:10, nrow = 4, byrow = TRUE))
(	mm <- matrix(c(5:15), nrow = 4, byrow = FALSE))
(new <- matrix(c(3:14), nrow = 3, byrow = FALSE))
( x <- matrix(1:6, 2, 3));
(x[1, ])  